package com.employeeapp.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "PermanentEmployee2")
public class PermanentEmployee extends Employee
{
	private double insurance;
	private String asset;
	
	public PermanentEmployee() {
		// TODO Auto-generated constructor stub
	}

	public PermanentEmployee(String name, String email,double insurance, String asset) {
		super(name,email);
		this.insurance = insurance;
		this.asset = asset;
	}

	@Override
	public String toString() {
		return "PermanentEmployee [insurance=" + insurance + ", asset=" + asset + "]";
	}

	public double getInsurance() {
		return insurance;
	}

	public void setInsurance(double insurance) {
		this.insurance = insurance;
	}

	public String getAsset() {
		return asset;
	}

	public void setAsset(String asset) {
		this.asset = asset;
	}
	
	

}
