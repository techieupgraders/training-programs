package com.employeeapp.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
public class ContractEmployee extends Employee
{
	@Column
	private String contractor;
	
	public ContractEmployee() {
		// TODO Auto-generated constructor stub
	}

	public ContractEmployee(String name, String email, String contractor) {
		super(name,email);
				this.contractor = contractor;
	}

	public String getContractor() {
		return contractor;
	}

	public void setContractor(String contractor) {
		this.contractor = contractor;
	}

	@Override
	public String toString() {
		return "ContractEmployee [contractor=" + contractor + "]";
	}

}
