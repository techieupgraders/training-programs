package com.employeeapp.main;

import java.util.Scanner;

import com.employeeapp.bean.ContractEmployee;
import com.employeeapp.bean.PermanentEmployee;
import com.employeeapp.database.DBUtil;
import jakarta.persistence.EntityManager;

public class MainApp 
{
	public static void main(String[] args)
	{
		int ans= 0 , id=0;
		Scanner sc= new Scanner(System.in);

		EntityManager manager = DBUtil.getManager();
		manager.getTransaction().begin(); 
		
		PermanentEmployee pemp1=new PermanentEmployee("Sam","sam@gmail.com",500000, "Laptop");
		PermanentEmployee pemp2=new PermanentEmployee("Jenny", "jenny@yahoo.com" ,700000, "Chair");
		manager.persist(pemp1); 
		manager.persist(pemp2);
		

		ContractEmployee cemp1 = new ContractEmployee("Priya", "priya@google.com" ,"Buzzoworks");
		ContractEmployee cemp2 = new ContractEmployee("Kia", "kia@yahoo.com" ,"ITC Ltd");
		manager.persist(cemp1);
		manager.persist(cemp2);
		manager.getTransaction().commit();
		
		System.out.println("All data updated !!");

	}
}
