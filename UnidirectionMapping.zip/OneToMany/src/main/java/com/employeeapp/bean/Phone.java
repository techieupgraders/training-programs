package com.employeeapp.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Telephone")
public class Phone
{
	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO ) //default stratergy AUTO
	private int id;
	
	@Column(name = "Type")
	private String type;
	
	@Column
	private long phonenumber;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public long getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(long phonenumber) {
		this.phonenumber = phonenumber;
	}
public Phone() {
	// TODO Auto-generated constructor stub
}
}
