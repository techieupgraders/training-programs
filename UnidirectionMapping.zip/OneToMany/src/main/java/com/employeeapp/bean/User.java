package com.employeeapp.bean;

import java.util.ArrayList;
import java.util.Collection;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "UserPh")
public class User {
	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO ) //default stratergy AUTO
	private int id;

	@Column(name = "username")
	private String username;

	@OneToMany
	@JoinTable(name="UserPh_TelePhoneJoin", joinColumns = @JoinColumn(name="UserId"),
	inverseJoinColumns = @JoinColumn(name="TelePhoneId"))
	private Collection<Phone> phones = new ArrayList<>();

	public User() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Collection<Phone> getPhones() {
		return phones;
	}

	public void setPhones(Phone phone) 
	{
		 getPhones().add(phone);
	}


}
