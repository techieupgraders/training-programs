package com.employeeapp.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Account 
{
	@Id
	@GeneratedValue
	private int id;
	private String accountName;
	
	@OneToOne(mappedBy = "account")
	private Employee employee;
	
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(String accountName) {
		super();
		this.accountName = accountName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	

	@Override
	public String toString() {
		return "Account [id=" + id + ", accountName=" + accountName + ", employee=" + employee + "]";
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	

}
