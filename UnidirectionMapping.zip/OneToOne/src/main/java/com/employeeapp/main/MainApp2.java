package com.employeeapp.main;


import java.util.List;

import com.employeeapp.bean.Account;
import com.employeeapp.bean.Employee;
import com.employeeapp.database.DBUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

public class MainApp2 
{
	public static void main(String[] args) {
		EntityManager manager = DBUtil.getManager();

		Employee e = new Employee("Jack Doe", "jack@gmail.com");

		Account account = new Account();
		account.setAccountName("Jack Doe Account");

		e.setAccount(account);		
		//account.setEmployee(e);

		manager.getTransaction().begin();
		manager.persist(e);
		manager.persist(account);
		manager.getTransaction().commit();
		System.out.println("Saved "+e);


		//Query query= manager.createQuery("SELECT e FROM Employee e ");

		//List<Employee> emp= (List<Employee>)query.getResultList();		
		//System.out.println("From Database "+emp.get(0).getAccount());

	}

}
