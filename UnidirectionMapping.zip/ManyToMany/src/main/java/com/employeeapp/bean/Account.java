package com.employeeapp.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Account2")
public class Account 
{
	@Id
	@GeneratedValue
	private int id;
	private String accountName;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(String accountName) {
		super();
		this.accountName = accountName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	

	@Override
	public String toString() {
		return "Account [id=" + id + ", accountName=" + accountName + "]";
	}

}
