package com.employeeapp.bean;

import java.util.ArrayList;
import java.util.Collection;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "UserProduct")
public class User {
	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO ) //default stratergy AUTO
	private int id;

	@Column(name = "username")
	private String username;

	@ManyToMany
	private Collection<Product> products = new ArrayList<>();

	public User() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Collection<Product> getproducts() {
		return products;
	}

	public void setproducts(Product Product) 
	{
		 getproducts().add(Product);
	}

	public User(int id, String username, Collection<Product> products) {
		super();
		this.id = id;
		this.username = username;
		this.products = products;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", products=" + products + "]";
	}


}
