package com.employeeapp.dao;

import java.util.Iterator;
import java.util.List;

import com.employeeapp.bean.Employee;
import com.employeeapp.database.DBUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class EmployeeDaoImpl implements EmployeeDao
{
	private static EntityManager manager;

	public EmployeeDaoImpl() 
	{
		manager = DBUtil.getManager();
	}

	public void beginTransaction() 
	{
		manager.getTransaction().begin();		
	}
	public void commitTransaction() 
	{
		manager.getTransaction().commit();		
	}
	@Override
	public Employee save(Employee employee) 
	{
		beginTransaction();
		manager.persist(employee);
		commitTransaction();
		System.out.println(employee+" saved");
		return employee;
	}

	@Override
	public Employee getById(int id)
	{
		beginTransaction();
		Employee e =manager.find(Employee.class, id);
		commitTransaction();
		return e;
	}

	@Override
	public Employee update(int id, String name, String email) 
	{
		beginTransaction();
		//	Employee e =manager.find(Employee.class, id);
		//		e.setName(name);
		//		e.setEmail(email);
		//		manager.persist(e);

		//update by query
		Query updateQuery= manager.createQuery("UPDATE Employee e SET e.email =:email, e.name=name"
				+ " WHERE e.id= :id")
				.setParameter("name", name)
				.setParameter("email", email)
				.setParameter("id", id);
		int rows= updateQuery.executeUpdate();
		commitTransaction();
		Employee e =manager.find(Employee.class, id);
		return e;
	}

	@Override
	public Employee delete(int id) 
	{
		beginTransaction();
		Employee e =manager.find(Employee.class, id);
		manager.remove(e);

		//delete by Query
		Query delete= manager.createQuery("DELETE from Employee e WHERE e.id = :id")
				.setParameter("id", id);
		int deletedRows= delete.executeUpdate();
		commitTransaction();
		return e;
	}

	@Override
	public List<Employee> getAll() {
		String jpql = "SELECT e FROM Employee e";
		TypedQuery<Employee> query = manager.createQuery(jpql, Employee.class);
		return query.getResultList();
	}

	@Override
	public Employee getByEmail(String email) 
	{
		String jpql = "SELECT e FROM Employee e WHERE e.email = :email";
		Employee emp =null;
		try 
		{
			emp = manager.createQuery(jpql, Employee.class)
					.setParameter("email", email)
					.getSingleResult();

			String jpql2 = "SELECT e FROM Employee e WHERE e.email = ?1 AND e.name = ?2";
			Employee emp2 = manager.createQuery(jpql2, Employee.class)
					.setParameter(1, email).setParameter(2, email)
					.getSingleResult();

			System.out.println(emp);
			return emp;
		} 
		catch (NoResultException exception) 
		{
			return emp; // Handle the case when no employee is found with the given email
		}

		///Another way////
		//		String jpql = "SELECT e FROM Employee e WHERE e.email = '"+email+"'";
		//		Employee emp =null;
		//		beginTransaction();
		//		Query query= manager.createQuery(jpql);
		//		List<Employee> list = query.getResultList();
		//		commitTransaction();
		//		if(list.size() == 0)
		//		{
		//			return emp;
		//		}
		//		else
		//		{
		//			emp=list.get(0);
		//			return emp;
		//		}


	}

	@Override
	public Employee getByName(String name) 
	{
		//using NamedQuery
		//		Query namedQuery = manager.createNamedQuery("Employee.getByNameEmployee", Employee.class);
		//		namedQuery.setParameter("name", name);
		//		return (Employee) namedQuery.getSingleResult();

		//using NativeQuery		
		//		Query nativeQuery= manager.createNativeQuery("Select * from employee where Name=:name", Employee.class);
		//		nativeQuery.setParameter("name", name);
		//		return (Employee) nativeQuery.getSingleResult();


		//using Criteria API
		CriteriaBuilder criteriaBuilder = manager.getCriteriaBuilder();
		CriteriaQuery<Employee> criteriaQuery = criteriaBuilder.createQuery(Employee.class);

		//to specify the query roots, by invoking from() of CriteriaQuery
		//query roots specify the domain object on which the query is evaluated
		Root<Employee> from = criteriaQuery.from(Employee.class);
		criteriaQuery.select(from);
		Predicate predicate = criteriaBuilder.equal(from.get("name"),name);
		criteriaQuery.where(predicate);
		Employee emp = manager.createQuery(criteriaQuery).getSingleResult();
		return emp;
	}

}
