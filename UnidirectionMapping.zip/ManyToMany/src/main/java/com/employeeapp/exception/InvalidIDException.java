package com.employeeapp.exception;

public class InvalidIDException extends Exception {

	public InvalidIDException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
