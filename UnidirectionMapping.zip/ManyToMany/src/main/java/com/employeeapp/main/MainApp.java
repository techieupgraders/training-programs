package com.employeeapp.main;

import java.util.List;
import java.util.Scanner;

import com.employeeapp.bean.Employee;
import com.employeeapp.dao.EmployeeDaoImpl;
import com.employeeapp.exception.EmployeeAlreadyExistsException;
import com.employeeapp.exception.EmployeeNotFoundException;
import com.employeeapp.exception.InvalidIDException;
import com.employeeapp.service.EmployeeService;
import com.employeeapp.service.EmployeeServiceImpl;

public class MainApp 
{
	public static void main(String[] args)
	{
		int ans= 0 , id=0;
		Scanner sc= new Scanner(System.in);

		EmployeeService service = new EmployeeServiceImpl();
		Employee emp ;
		do 
		{
			System.out.println("1.Add Employee\n2.Get Employee"
					+ "\n3.Update Employee\n4.Remove Employee\n5.Get All Employee");

			System.out.println("Enter your choice ");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter employee Email ");
				String email=sc.next();
				System.out.println("Enter employee name");
				String name=sc.next();

				try 
				{
					emp = service.addEmployee(email,name);
					System.out.println("Employee added = "+emp);
				} 
				catch (EmployeeAlreadyExistsException e) 
				{
					System.out.println(e.getMessage());
				} catch (InvalidIDException e) 
				{
					System.out.println(e.getMessage());
				}

				break;
			case 2:
				System.out.println("Enter employee ID ");
				id =sc.nextInt();
				try 
				{
					emp = service.getEmployee(id);
					System.out.println(emp);

				} catch (EmployeeNotFoundException e) 
				{
					System.out.println(e.getMessage());
				} catch (InvalidIDException e) 
				{
					System.out.println(e.getMessage());
				}

				break;
			case 3:
				System.out.println("Enter employee ID ");
				id =sc.nextInt();
				System.out.println("Enter updated employee Email ");
				email=sc.next();
				System.out.println("Enter updated employee name");
				name=sc.next();
				try
				{
					emp = service.modifyEmployee(id, name,email);
					System.out.println("Employee Updated as "+emp);
				} 
				catch (EmployeeNotFoundException e) 
				{
					System.out.println(e.getMessage());
				} 
				catch (InvalidIDException e) 
				{
					System.out.println(e.getMessage());
				} catch (EmployeeAlreadyExistsException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				System.out.println("Enter employee ID ");
				id =sc.nextInt();
				try
				{
					emp = service.removeEmployee(id);
					System.out.println("Employee removed -"+emp);
				} 
				catch (EmployeeNotFoundException e) 
				{
					System.out.println(e.getMessage());
				} 
				catch (InvalidIDException e) 
				{
					System.out.println(e.getMessage());
				}

				break;
			case 5:
				List<Employee> list = service.getAllEmployee();
				System.out.println(list);
				
				System.out.println("Enter employee name");
				name=sc.next();
				
				Employee e = new EmployeeDaoImpl().getByName(name);
				System.out.println(e);
				break;
			default:
				break;
			}
			System.out.println("want to continue ?(1 to continue)");
			ans= sc.nextInt();
		} while (ans==1);

	}


}
