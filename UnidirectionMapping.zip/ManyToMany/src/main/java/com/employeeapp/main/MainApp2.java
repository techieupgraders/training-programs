package com.employeeapp.main;


import java.util.List;

import com.employeeapp.bean.Account;
import com.employeeapp.bean.Employee;
import com.employeeapp.bean.Product;
import com.employeeapp.bean.User;
import com.employeeapp.database.DBUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

public class MainApp2 
{
	public static void main(String[] args) {
		EntityManager manager = DBUtil.getManager();
		
		User u1= new User();
		u1.setUsername("Jack");
		
		Product product= new Product();
		product.setPrice(3500);
		product.setType("Rare Use");
		product.getUsers().add(u1);
		u1.getproducts().add(product);
		
		
		
		
		
		manager.getTransaction().begin();
		manager.persist(product);
		manager.persist(u1);
		manager.getTransaction().commit();
		System.out.println("Saved "+u1);
		
		
		
		///////////////////////////////////////////////////
//		Employee e1 = new Employee("Jack Doe", "jack@gmail.com");
//		Employee e2 = new Employee("Jenny Doe", "jenny@gmail.com");
//
//		Account account = new Account();
//		account.setAccountName("Jack Doe Account");
//
//		e1.setAccount(account);		
//		e2.setAccount(account);		
//
//		manager.getTransaction().begin();
//		manager.persist(e1);
//		manager.persist(e2);
//		manager.persist(account);
//		manager.getTransaction().commit();
//		System.out.println("Saved "+e1);
//		System.out.println("Saved "+e2);
		///////////////////////////////////////////////////


		//Query query= manager.createQuery("SELECT e FROM Employee e ");

		//List<Employee> emp= (List<Employee>)query.getResultList();		
		//System.out.println("From Database "+emp.get(0).getAccount());

	}

}
