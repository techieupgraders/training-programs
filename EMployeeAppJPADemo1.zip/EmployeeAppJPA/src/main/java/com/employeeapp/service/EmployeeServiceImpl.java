package com.employeeapp.service;

import java.util.List;
import java.util.Optional;

import com.employeeapp.bean.Employee;
import com.employeeapp.dao.EmployeeDao;
import com.employeeapp.dao.EmployeeDaoImpl;
import com.employeeapp.exception.EmployeeAlreadyExistsException;
import com.employeeapp.exception.EmployeeNotFoundException;
import com.employeeapp.exception.InvalidIDException;

public class EmployeeServiceImpl implements EmployeeService 
{
	private EmployeeDao dao;
		public EmployeeServiceImpl() 
		{
			dao  = new EmployeeDaoImpl();
		}
	

	public EmployeeServiceImpl(EmployeeDao dao) 
	{
		super();
		this.dao = dao;
	}
	

	@Override
	public Employee addEmployee(String email , String name) throws InvalidIDException, EmployeeAlreadyExistsException
	{
		// TODO Auto-generated method stub
		Employee emp = new Employee();
		emp.setEmail(email);
		emp.setName(name);
		
		if(emp.getEmail() == null)
		{
			throw new InvalidIDException("Invalid Email "+email+" entered !!");
		}
		Optional<Employee> employee= Optional.ofNullable(dao.getByEmail(email));
		if(employee.isPresent()) 
		{			
			throw new EmployeeAlreadyExistsException("Employee with Email "+email+ " is already exists");		 
		}
		else
		{
			emp = dao.save(emp);
		}
		return emp;
	}

	

	@Override
	public Employee getEmployee(int id) throws InvalidIDException, EmployeeNotFoundException{

		if(id <=0)
		{
			throw new InvalidIDException("Invalid ID "+id+" entered !!");
		}
		Optional<Employee> employee= Optional.ofNullable(dao.getById(id));
		if(employee.isPresent()) 
		{			
			return employee.get();
		}
		else
		{
			throw new EmployeeNotFoundException("Employee with ID "+id+" not found !!");
		}

	}

	@Override
	public Employee modifyEmployee(int id, String name, String email) throws EmployeeNotFoundException, InvalidIDException, EmployeeAlreadyExistsException {
		if(id <=0)
		{
			throw new InvalidIDException("Invalid ID "+id+" entered !!");
		}
		Employee emp = new Employee();
		emp.setEmail(email);
		emp.setName(name);
		
		if(emp.getEmail() == null)
		{
			throw new InvalidIDException("Invalid Email "+email+" entered !!");
		}
		Optional<Employee> employee= Optional.ofNullable(dao.getByEmail(email));
		if(employee.isPresent()) 
		{			
			throw new EmployeeAlreadyExistsException("Employee with Email "+email+ " is already exists");		 
		}
		 employee= Optional.ofNullable(dao.getById(id));
		if(employee.isPresent()) 
		{		
			emp = dao.update(id , name, email);
			return emp;
		}
		else
		{
			throw new EmployeeNotFoundException("Employee with ID "+id+" not found !!");
		}
	}

	@Override
	public Employee removeEmployee(int id) throws EmployeeNotFoundException, InvalidIDException {
		Employee emp;
		if(id <=0)
		{
			throw new InvalidIDException("Invalid ID "+id+" entered !!");
		}
		Optional<Employee> employee= Optional.ofNullable(dao.getById(id));
		if(employee.isPresent()) 
		{		
			emp = dao.delete(id);
			return emp;
		}
		else
		{
			throw new EmployeeNotFoundException("Employee with ID "+id+" not found !!");
		}
	}

	@Override
	public List<Employee> getAllEmployee() 
	{
		// TODO Auto-generated method stub
		return dao.getAll();
	}



}
