package com.employeeapp.service;

import java.util.List;

import com.employeeapp.bean.Employee;
import com.employeeapp.exception.EmployeeAlreadyExistsException;
import com.employeeapp.exception.EmployeeNotFoundException;
import com.employeeapp.exception.InvalidIDException;

public interface EmployeeService 
{
	Employee addEmployee(String email, String name) throws EmployeeAlreadyExistsException , InvalidIDException;
	//valid scenario
	//Given - valid id, name which does not exist
	//when- addEmployee()
	//then- Employee type object
	
	
	Employee getEmployee(int id) throws EmployeeNotFoundException , InvalidIDException;
	Employee modifyEmployee(int id, String name, String email) throws EmployeeNotFoundException , InvalidIDException, EmployeeAlreadyExistsException;
	Employee removeEmployee(int id)throws EmployeeNotFoundException , InvalidIDException;
	List<Employee> getAllEmployee();
}
