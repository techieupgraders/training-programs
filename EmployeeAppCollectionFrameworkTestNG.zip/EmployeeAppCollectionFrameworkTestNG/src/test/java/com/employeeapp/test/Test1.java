package com.employeeapp.test;

import static org.junit.Assert.assertEquals;

import org.testng.annotations.Test;

public class Test1 
{
	@Test
	public void checkEqualNames()
	{
		String exp="John";
		String act="Jenny";
		assertEquals("Failure-Strings are not Equal", exp,act);		
	}

}
