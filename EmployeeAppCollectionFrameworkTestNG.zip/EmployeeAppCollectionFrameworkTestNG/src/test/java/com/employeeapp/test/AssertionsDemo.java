package com.employeeapp.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.testng.annotations.BeforeClass;

public class AssertionsDemo 
{
	//assertions are the utility methods to support 
	//the asserting conditions in tests

	@Test
	public void checkEqualNames()
	{
		String exp="John";
		String act="Jenny";
		assertEquals("Failure-Strings are not Equal", exp,act);		
	}

	@Test
	public void checkEqualArrays()
	{
		char[] exp= {'J','o','h','n'}; //null;
		char[] act= new String("John").toCharArray(); //null;

		assertArrayEquals("Failure-Arrays are not Equal", exp,act);
		//assertNull(act); 
		//assertNotNull(act);

		//act=exp;
		//assertSame(exp, act);
		//assertTrue(Arrays.equals(exp, act));
		//assertThat(act, is(exp)); //from JUnit4
	}

	@Test
	public void checkFail()
	{
		try 
		{
			String str= null; //"hh";
			System.out.println(str.length());
			fail("Exception Not occur..");
		}
		catch (NullPointerException e) 
		{
			System.out.println("Exception occur");
			assertEquals(NullPointerException.class.getName(), e.getClass().getName());
		}
	}

	@Test
	public void checkAll()
	{
		assertAll("Test All Functions!!",
				()->assertEquals(64, (8*8)),
				()->assertEquals(5, new String("INDIA").length()),
				()->assertThrows(NullPointerException.class, 
						()->
							{
								String str=null;
								System.out.println(str.length());
							})
				);
	}

	@BeforeEach
	public void before()
	{
		System.out.println("Before");
	}

	@RepeatedTest(value = 3)
	//@Test
	public void checkIterables(RepetitionInfo info)
	{
		ArrayList<String> l1= new ArrayList<>();
		l1.add("John"); l1.add("Jenny"); l1.add("Jack");
		Iterable<String> i1= l1;
		System.out.println(l1);
		LinkedHashSet<String> l2= new LinkedHashSet<>();
		l2.add("John"); l2.add("Jenny"); l2.add("Jack");
		Iterable<String> i2= l2;
		System.out.println(l2);

		System.out.println(info.getCurrentRepetition());

		assertIterableEquals(i1, i2);		
	}
	@AfterEach
	public void after()
	{
		System.out.println("After");
	}
	@BeforeAll
	public static void beforeall()
	{
		System.out.println("beforeall");
	}
	@AfterAll
	public static void afterAll()
	{
		System.out.println("AfterAll");
	}

	@Nested
	@DisplayName("Test for Calculate Feature")
	class CalculateFeature
	{
		@Test
		public void add()
		{
			System.out.println("add");
			assertEquals(10, (5+5));
		}

		@Test
		public void sub()
		{
			System.out.println("sub");
			assertEquals(10, (15-5));
		}

		@Test
		public void div()
		{
			System.out.println("div");
			assertEquals(10, (50/5));
		}
	}
}



