package com.employeeapp.test;
enum IntEnum {
    VALUE_ONE(201),
    VALUE_TWO(202),
    VALUE_THREE(203);

    private final int value;

    IntEnum(int value) 
    {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}