package com.employeeapp.test;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.stream.Stream;

import org.junit.Ignore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.employeeapp.bean.Employee;
import com.employeeapp.dao.EmployeeDao;
import com.employeeapp.exception.EmployeeAlreadyExistsException;
import com.employeeapp.exception.EmployeeNotFoundException;
import com.employeeapp.exception.InvalidIDException;
import com.employeeapp.service.EmployeeService;
import com.employeeapp.service.EmployeeServiceImpl;

import net.bytebuddy.asm.Advice.Argument;


public class EmployeeServiceTest 
{
	private static EmployeeService service;

	@Mock
	private static EmployeeDao mockDao;

	@BeforeEach
	public void setUp()
	{
		//mockDao= Mockito.mock(EmployeeDao.class);
		MockitoAnnotations.openMocks(this);
		service = new EmployeeServiceImpl(mockDao);
	}

	//@Ignore
	@Test
	public void getEmployeeInvalidIDExceptionTest()
	{
		int id = -101;		
		//assertNotEquals(100, id);
		assertThrows(InvalidIDException.class,()->service.getEmployee(id));
	}

	@Ignore
	@Test
	public void getEmployeeEmployeeNotFoundExceptionTest()
	{
		int id = 200;		
		//assertNotEquals(100, id);
		when(mockDao.getById(id)).thenReturn(null);
		assertThrows(EmployeeNotFoundException.class,()->service.getEmployee(id));
	}

	@Test
	public void getEmployeeTest() throws EmployeeNotFoundException, InvalidIDException
	{
		int id = 101;		
		Employee e=  new Employee(101,"John");
		when(mockDao.getById(id)).thenReturn(new Employee(101,"John"));
		assertEquals(e, service.getEmployee(id));
	}

	@Ignore
	@Test
	public void addEmployeeEmployeeAlreadyExistsExceptionTest()
	{
		int id=107;
		String name= "John";
		Employee e=  new Employee(107,"John");
		when(mockDao.getById(id)).thenReturn(new Employee(107,"John"));
		assertThrows(EmployeeAlreadyExistsException.class, ()->service.addEmployee(id, name));
	}

	//Using Mockito
	//csv file
	//	id	name
	//	101	John
	//	110	Snehal
	//	210	Misha

	@Ignore
	@ParameterizedTest
	//@CsvFileSource(files = "src/test/resources/Book1.csv", numLinesToSkip = 1)
	//@EnumSource(IntEnum.class)
	//public void addEmployeeTest(IntEnum id2) throws EmployeeAlreadyExistsException, InvalidIDException
	@MethodSource("getEmployeeValues")
	//@ValueSource(ints = {301,302,303})
	public void addEmployeeTest(int id, String name) throws EmployeeAlreadyExistsException, InvalidIDException
	{
		//int id= id2.getValue();

		//int id=107;

		//String name="Snehal";

		Employee e= new Employee(id, name);

		when(mockDao.getById(id)).thenReturn(null);

		//mocked behavior of save() of Dao
		when(mockDao.save(new Employee(id, name))).thenReturn(e);

		Employee expected= new Employee(id, name);

		assertEquals(expected, service.addEmployee(id, name));	
		System.out.println(id+" "+name);
	}

	private static Stream<Arguments> getEmployeeValues()
	{
		return Stream.of(Arguments.of(501,"Sima"),
				Arguments.of(502,"Joe"),
				Arguments.of(503,"Rima"),
				Arguments.of(504,"Lisa")
				);

	}



	@Ignore
	@ParameterizedTest 
	@CsvSource({ "101, John, Lisa", "102, Sam, Kia"})
	public void modifyEmployeeTest(int id, String name, String newName) throws EmployeeNotFoundException, InvalidIDException
	{
		//int id=101;
		//String name="Ram";
		//String newName="Lisa";

		//set behavior of dao methods that are called in service.modify()
		when(mockDao.getById(id)).thenReturn(new Employee(id,name));

		when(mockDao.update(id, newName)).thenReturn(new Employee(id, newName));

		//action
		Employee actual= service.modifyEmployee(id, newName);
		Employee expected = new Employee(id, newName);
		System.out.println("csv source : "+id+" "+name+" "+newName);
		assertEquals(expected, actual);	

	}

	@Ignore
	@Test
	public void modifyEmployeeEmployeeNotFoundExceptionTest() throws EmployeeNotFoundException, InvalidIDException
	{
		int id=101;
		String name="Ram";
		String newName="Lisa";

		//set behavior of dao methods that are called in service.modify()
		when(mockDao.getById(id)).thenReturn(null);

		assertThrows(EmployeeNotFoundException.class,()->service.modifyEmployee(id, newName));		
	}
}
