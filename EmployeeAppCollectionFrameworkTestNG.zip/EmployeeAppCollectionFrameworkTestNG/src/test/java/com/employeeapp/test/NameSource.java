package com.employeeapp.test;

public enum NameSource {

}
