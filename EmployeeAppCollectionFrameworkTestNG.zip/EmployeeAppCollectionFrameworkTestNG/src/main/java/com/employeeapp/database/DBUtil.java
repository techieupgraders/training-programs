package com.employeeapp.database;

import java.util.ArrayList;
import java.util.List;

import com.employeeapp.bean.Employee;

public class DBUtil 
{
	public static List<Employee> list = new ArrayList<>();
	
	static 
	{
		list.add(new Employee(101, "John"));
		list.add(new Employee(102, "Sam"));
		list.add(new Employee(103, "John"));
		list.add(new Employee(104, "Jenny"));
		list.add(new Employee(105, "Misha"));
	}

}
