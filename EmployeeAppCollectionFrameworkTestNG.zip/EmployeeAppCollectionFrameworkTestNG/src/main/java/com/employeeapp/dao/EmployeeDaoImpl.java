package com.employeeapp.dao;

import java.util.Iterator;
import java.util.List;

import com.employeeapp.bean.Employee;
import com.employeeapp.database.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao
{

	@Override
	public Employee save(Employee employee) 
	{
		DBUtil.list.add(employee);
		return employee;
	}

	@Override
	public Employee getById(int id)
	{
		
		Iterator<Employee> itr = DBUtil.list.iterator();
		while(itr.hasNext())
		{
			Employee emp = itr.next();
			if(emp.getId()==id)
			{
				return emp;
			}
		}
		return null;
	}

	@Override
	public Employee update(int id , String name) 
	{
		Employee emp = null;
		Iterator<Employee> itr = DBUtil.list.iterator();
		while(itr.hasNext())
		{
			emp = itr.next();
			if(emp.getId()==id)
			{
				emp.setName(name);
				break;
			}
		}
		return emp;
		
	}

	@Override
	public Employee delete(int id) 
	{
		Employee emp = null;
		Iterator<Employee> itr = DBUtil.list.iterator();
		while(itr.hasNext())
		{
			emp = itr.next();
			if(emp.getId()==id)
			{
				itr.remove();
				break;
			}
		}
		return emp;
	}

	@Override
	public List<Employee> getAll() 
	{
		return DBUtil.list;
	}

}
