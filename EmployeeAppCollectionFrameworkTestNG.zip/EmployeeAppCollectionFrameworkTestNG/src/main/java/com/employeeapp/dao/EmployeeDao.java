package com.employeeapp.dao;

import java.util.List;

import com.employeeapp.bean.Employee;

public interface EmployeeDao 
{
	Employee save(Employee employee);
	Employee getById(int id);
	Employee update(int id, String name);
	Employee delete(int id);
	List<Employee> getAll();
}
